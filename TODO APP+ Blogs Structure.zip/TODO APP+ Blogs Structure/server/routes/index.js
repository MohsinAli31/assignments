import Users from '../controllers/user';

export default (app) => {
	app.get('/api', (req, res) =>
		res.status(200).send({
			message: 'Welcome to the BookStore API!',
		})
	);

	app.get('/api/users', Users.list); // API route for user to get all books in the database

	app.post('/api/users', Users.signUp); // API route for user to signup
	app.put('/api/users/:userId', Users.modify); // API route for user to edit a book

	app.delete('/api/users/:userId', Users.delete); // API route for user to delete a book
};
