import model from '../models';

const { User } = model;

class Users {
	static delete(req, res) {
		return User.findByPk(req.params.userId)
			.then((user) => {
				if (!user) {
					return res.status(400).send({
						message: 'user Not Found',
					});
				}
				return user
					.destroy()
					.then(() =>
						res.status(200).send({
							message: 'User successfully deleted',
						})
					)
					.catch((error) => res.status(400).send(error));
			})
			.catch((error) => res.status(400).send(error));
	}

	static modify(req, res) {
		const { name, username, email, password } = req.body;
		return User.findByPk(req.params.userId)
			.then((user) => {
				user.update({
					name: name || user.name,
					username: username || user.username,
					email: email || user.email,
					password: password || user.password,
				})
					.then((updatedUser) => {
						res.status(200).send({
							message: 'User updated successfully',
							data: {
								name: name || updatedUser.name,
								username: username || updatedUser.username,
								email: email || updatedUser.email,
								password: password || updatedUser.passowrd,
							},
						});
					})
					.catch((error) => res.status(400).send(error));
			})
			.catch((error) => res.status(400).send(error));
	}

	static list(req, res) {
		return User.findAll().then((users) => res.status(200).send(users));
	}

	static signUp(req, res) {
		const { name, username, email, password } = req.body;
		return User.create({
			name,
			username,
			email,
			password,
		}).then((userData) =>
			res.status(201).send({
				success: true,
				message: 'User successfully created',
				userData,
			})
		);
	}
}

export default Users;
